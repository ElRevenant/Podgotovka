import {useMemo} from 'react';

interface SnowFlakeSpec {
  id: number;
  leftPct: number;
  sizePx: number;
  blurPx: number;
  opacityDark: number;
  opacityLight: number;
  durationSec: number;
  delaySec: number;
  driftPx: number;
  warmTint: boolean;
}

// Deterministic pseudo-random helper so SSR/re-renders never cause jitter
function seededUnit(seed: number): number {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}

interface AmbientSnowBackdropProps {
  snowEnabled: boolean;
  warmGlowEnabled: boolean;
}

export function AmbientSnowBackdrop({
  snowEnabled,
  warmGlowEnabled,
}: AmbientSnowBackdropProps) {
  const flakes = useMemo<SnowFlakeSpec[]>(() => {
    const items: SnowFlakeSpec[] = [];
    const total = 42;
    for (let i = 0; i < total; i++) {
      const r1 = seededUnit(i + 1);
      const r2 = seededUnit(i + 101);
      const r3 = seededUnit(i + 211);
      const r4 = seededUnit(i + 307);
      const r5 = seededUnit(i + 409);

      // 3 optical depth planes: far tiny, mid soft, foreground bokeh
      const layer = i % 3;
      const sizePx =
        layer === 0
          ? 2.5 + r2 * 2
          : layer === 1
            ? 4.5 + r2 * 3
            : 8 + r2 * 5.5;
      const blurPx =
        layer === 0
          ? 1 + r3 * 0.8
          : layer === 1
            ? 2.2 + r3 * 1.4
            : 4.5 + r3 * 2.5;
      const durationSec =
        layer === 0
          ? 22 + r4 * 14
          : layer === 1
            ? 16 + r4 * 10
            : 12 + r4 * 8;

      items.push({
        id: i,
        leftPct: Math.round(r1 * 1000) / 10,
        sizePx: Math.round(sizePx * 10) / 10,
        blurPx: Math.round(blurPx * 10) / 10,
        opacityDark:
          layer === 0
            ? 0.16 + r5 * 0.14
            : layer === 1
              ? 0.14 + r5 * 0.14
              : 0.08 + r5 * 0.09,
        opacityLight:
          layer === 0
            ? 0.24 + r5 * 0.14
            : layer === 1
              ? 0.18 + r5 * 0.12
              : 0.12 + r5 * 0.08,
        durationSec: Math.round(durationSec * 10) / 10,
        delaySec: -Math.round(r5 * durationSec * 10) / 10,
        driftPx: Math.round((r3 - 0.5) * 68),
        // ~20% of foreground bokeh flakes pick up a subtle warm hearth-amber glint
        warmTint: layer === 2 && r4 > 0.55,
      });
    }
    return items;
  }, []);

  if (!snowEnabled && !warmGlowEnabled) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="no-print fixed inset-0 z-0 pointer-events-none overflow-hidden select-none"
    >
      {/* Organic Warm Ambient Light Pools (Cozy Lamp / Hearth Vibe) */}
      {warmGlowEnabled && (
        <>
          <div className="ambient-warm-orb ambient-warm-orb-1" />
          <div className="ambient-warm-orb ambient-warm-orb-2" />
          <div className="ambient-warm-orb ambient-warm-orb-3" />
        </>
      )}

      {/* Softly Blurred Depth-Layered Snowflakes */}
      {snowEnabled && (
        <div className="ambient-snow-layer">
          {flakes.map((flake) => (
            <span
              key={flake.id}
              className={`ambient-snowflake ${
                flake.warmTint && warmGlowEnabled ? 'ambient-snowflake-warm' : ''
              }`}
              style={
                {
                  left: `${flake.leftPct}%`,
                  width: `${flake.sizePx}px`,
                  height: `${flake.sizePx}px`,
                  filter: `blur(${flake.blurPx}px)`,
                  animationDuration: `${flake.durationSec}s`,
                  animationDelay: `${flake.delaySec}s`,
                  '--snow-drift': `${flake.driftPx}px`,
                  '--snow-opacity-dark': flake.opacityDark,
                  '--snow-opacity-light': flake.opacityLight,
                } as React.CSSProperties
              }
            />
          ))}
        </div>
      )}
    </div>
  );
}
