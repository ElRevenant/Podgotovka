import {FormEvent, useEffect, useMemo, useState} from 'react';
import {
  Award,
  CheckCircle2,
  Clock,
  Coffee,
  Film,
  Gamepad2,
  Lock,
  Pizza,
  Plus,
  Sparkles,
  Trash2,
  Trophy,
  Unlock,
  X,
} from 'lucide-react';
import {RewardItem, RewardSystemState} from '../types/study';
import {DEFAULT_REWARDS} from '../utils/rewards';

interface RewardsModalProps {
  rewardState: RewardSystemState;
  onClaimReward: (reward: RewardItem) => void;
  onEndActiveBreak: () => void;
  onAddCustomReward: (reward: RewardItem) => void;
  onDeleteReward: (rewardId: string) => void;
  onRestoreDefaults: () => void;
  onClose: () => void;
}

function RewardIcon({
  kind,
  className = 'h-5 w-5',
}: {
  kind: RewardItem['icon'];
  className?: string;
}) {
  switch (kind) {
    case 'dota':
      return <Gamepad2 className={className} />;
    case 'coffee':
      return <Coffee className={className} />;
    case 'movie':
      return <Film className={className} />;
    case 'food':
      return <Pizza className={className} />;
    case 'party':
      return <Trophy className={className} />;
    default:
      return <Sparkles className={className} />;
  }
}

function formatCountdown(ms: number): string {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function RewardsModal({
  rewardState,
  onClaimReward,
  onEndActiveBreak,
  onAddCustomReward,
  onDeleteReward,
  onRestoreDefaults,
  onClose,
}: RewardsModalProps) {
  const [nowMs, setNowMs] = useState(() => Date.now());
  const [addOpen, setAddOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCost, setNewCost] = useState('120');
  const [newMinutes, setNewMinutes] = useState('45');
  const [newIcon, setNewIcon] = useState<RewardItem['icon']>('dota');

  useEffect(() => {
    const id = window.setInterval(() => setNowMs(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const sortedRewards = useMemo(
    () => [...rewardState.rewards].sort((a, b) => a.costXp - b.costXp),
    [rewardState.rewards],
  );

  const nextLocked = useMemo(
    () => sortedRewards.find((r) => rewardState.balanceXp < r.costXp) ?? null,
    [sortedRewards, rewardState.balanceXp],
  );

  const activeBreakRemainingMs = rewardState.activeBreak
    ? Math.max(0, rewardState.activeBreak.endsAt - nowMs)
    : 0;

  const handleCreateCustom = (e: FormEvent) => {
    e.preventDefault();
    const cleanTitle = newTitle.trim();
    if (!cleanTitle) return;
    const cost = Math.max(10, Math.min(2000, Number(newCost) || 100));
    const mins = Math.max(5, Math.min(300, Number(newMinutes) || 30));

    onAddCustomReward({
      id: `rew_custom_${Date.now().toString(36)}`,
      title: cleanTitle,
      subtitle: `Твоя личная цель (${mins} мин отдыха)`,
      costXp: cost,
      breakMinutes: mins,
      icon: newIcon,
      permitQuote: `ДОПУСК ВЫДАН! «${cleanTitle}» официально разрешено — ты честно заработал ${cost} XP!`,
      isCustom: true,
    });
    setNewTitle('');
    setNewCost('120');
    setNewMinutes('45');
    setAddOpen(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Вознаграждения и допуск к отдыху"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#04070D]/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto"
    >
      <div className="w-full max-w-4xl rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0E1522] shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Gamepad2 className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-bold text-slate-950 dark:text-[#F3F4F6] truncate">
                Награды и официальный допуск к Доте / отдыху
              </h2>
              <p className="text-xs text-slate-500 dark:text-[#94A3B8] truncate">
                Закрывай этапы подготовки → копи XP → получай официальное разрешение пойти катать без чувства вины
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть"
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:text-[#94A3B8] dark:hover:bg-[#182235] cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Active Official Break Permit */}
          {rewardState.activeBreak && activeBreakRemainingMs > 0 && (
            <div className="rounded-2xl border-2 border-emerald-500 bg-gradient-to-br from-emerald-50 to-teal-50/60 dark:from-emerald-950/50 dark:to-[#13221c] p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-600 text-white text-xs font-extrabold uppercase tracking-wider">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Разрешено
                  </span>
                  <h3 className="text-lg font-extrabold text-emerald-950 dark:text-emerald-200">
                    {rewardState.activeBreak.title}
                  </h3>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/90 dark:bg-[#111916] border border-emerald-300 dark:border-emerald-700 font-mono text-base font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                  <Clock className="h-4 w-4" />
                  <span>{formatCountdown(activeBreakRemainingMs)}</span>
                </div>
              </div>

              <p className="text-sm font-medium text-emerald-900 dark:text-emerald-100 leading-relaxed">
                {rewardState.activeBreak.permitQuote}
              </p>

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <span className="text-xs text-emerald-800/80 dark:text-emerald-300/80">
                  Когда таймер закончится — пора возвращаться к билетам!
                </span>
                <button
                  type="button"
                  onClick={onEndActiveBreak}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-emerald-400 dark:border-emerald-700 bg-white/80 dark:bg-[#16251f] text-emerald-900 dark:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 cursor-pointer"
                >
                  Завершить отдых досрочно и вернуться к учёбе
                </button>
              </div>
            </div>
          )}

          {/* XP Wallet & Next Stage Progress */}
          <div className="grid sm:grid-cols-3 gap-3">
            <div className="rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0E1522] p-4">
              <div className="text-xs text-slate-500 dark:text-[#94A3B8]">
                Доступно для траты
              </div>
              <div className="mt-1 text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400 tabular-nums">
                {rewardState.balanceXp} XP
              </div>
              <div className="mt-1 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                Сегодня заработано: +{rewardState.earnedTodayXp} XP
              </div>
            </div>

            <div className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0E1522] p-4 flex flex-col justify-between space-y-2">
              {nextLocked ? (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="font-semibold text-slate-800 dark:text-[#E5E7EB]">
                      Следующий этап:{' '}
                      <strong className="text-sky-700 dark:text-sky-400">
                        {nextLocked.title}
                      </strong>
                    </span>
                    <span className="font-mono font-bold text-slate-700 dark:text-[#D1D5DB] tabular-nums">
                      Осталось {nextLocked.costXp - rewardState.balanceXp} XP
                    </span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-slate-200 dark:bg-[#131B2B] overflow-hidden">
                    <div
                      className="h-full bg-sky-500 transition-all duration-300"
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round(
                            (rewardState.balanceXp / Math.max(1, nextLocked.costXp)) *
                              100,
                          ),
                        )}%`,
                      }}
                    />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                    Примерно ещё{' '}
                    <strong className="text-slate-700 dark:text-[#D1D5DB]">
                      {Math.ceil((nextLocked.costXp - rewardState.balanceXp) / 10)}{' '}
                      карточек
                    </strong>{' '}
                    или{' '}
                    <strong className="text-slate-700 dark:text-[#D1D5DB]">
                      {Math.ceil((nextLocked.costXp - rewardState.balanceXp) / 25)}{' '}
                      решённых задач
                    </strong>{' '}
                    — и допуск твой!
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-3 my-auto">
                  <Award className="h-8 w-8 text-amber-500 shrink-0" />
                  <div>
                    <div className="text-sm font-bold text-slate-950 dark:text-white">
                      Все этапы наград открыты!
                    </div>
                    <div className="text-xs text-slate-600 dark:text-[#94A3B8]">
                      Можешь смело забрать любую награду ниже или добавить свою супер-цель.
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* How XP is Earned Strip */}
          <div className="rounded-xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0E1522] px-4 py-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-slate-600 dark:text-[#94A3B8]">
            <span className="font-semibold text-slate-900 dark:text-[#F3F4F6]">
              Как начисляются XP:
            </span>
            <span>
              Карточка хорошо/легко: <strong className="text-emerald-600 dark:text-emerald-400">+10 XP</strong>
            </span>
            <span>
              Сложная попытка: <strong className="text-sky-600 dark:text-sky-400">+4 XP</strong>
            </span>
            <span>
              Решённая задача: <strong className="text-emerald-600 dark:text-emerald-400">+25 XP</strong>
            </span>
            <span>
              Раунд «Найди ложь»: <strong className="text-rose-600 dark:text-rose-400">+15 XP</strong>
            </span>
            <span>
              Блиц-тест: <strong className="text-amber-600 dark:text-amber-400">+20 XP</strong>
            </span>
            <span>
              1 мин Pomodoro: <strong className="text-sky-600 dark:text-sky-400">+3 XP</strong>
            </span>
          </div>

          {/* Rewards Catalog */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-slate-950 dark:text-[#F3F4F6]">
                Этапы-допуски и магазин отдыха ({sortedRewards.length})
              </h3>
              <div className="flex items-center gap-2">
                {rewardState.rewards.length < DEFAULT_REWARDS.length && (
                  <button
                    type="button"
                    onClick={onRestoreDefaults}
                    className="text-xs text-slate-500 hover:text-slate-800 dark:text-[#94A3B8] dark:hover:text-white cursor-pointer"
                  >
                    Вернуть стандартные
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setAddOpen((v) => !v)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 dark:border-white/[0.08] text-slate-800 dark:text-[#E5E7EB] hover:bg-slate-100 dark:hover:bg-[#182235] cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5 text-sky-500" />
                  <span>Своя награда</span>
                </button>
              </div>
            </div>

            {/* Add Custom Reward Form */}
            {addOpen && (
              <form
                onSubmit={handleCreateCustom}
                className="rounded-xl border border-sky-300 dark:border-sky-800/70 bg-sky-50/50 dark:bg-sky-950/20 p-4 grid sm:grid-cols-[1fr_100px_100px_auto] gap-2.5 items-end"
              >
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-[#D1D5DB] mb-1">
                    Что разрешить себе?
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Например: 2 катки в CS2 или шаурма"
                    required
                    className="w-full rounded-lg border border-slate-300 dark:border-white/[0.08] bg-white dark:bg-[#0B101B] px-3 py-2 text-xs text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-[#D1D5DB] mb-1">
                    Цена (XP)
                  </label>
                  <input
                    type="number"
                    min={10}
                    max={2000}
                    value={newCost}
                    onChange={(e) => setNewCost(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 dark:border-white/[0.08] bg-white dark:bg-[#0B101B] px-2.5 py-2 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-[#D1D5DB] mb-1">
                    Минут отдыха
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={300}
                    value={newMinutes}
                    onChange={(e) => setNewMinutes(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 dark:border-white/[0.08] bg-white dark:bg-[#0B101B] px-2.5 py-2 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  <select
                    value={newIcon}
                    onChange={(e) =>
                      setNewIcon(e.target.value as RewardItem['icon'])
                    }
                    className="rounded-lg border border-slate-300 dark:border-white/[0.08] bg-white dark:bg-[#0B101B] px-2 py-2 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="dota">Игра</option>
                    <option value="coffee">Кофе</option>
                    <option value="movie">Кино</option>
                    <option value="food">Еда</option>
                    <option value="party">Пати</option>
                  </select>
                  <button
                    type="submit"
                    className="px-3.5 py-2 text-xs font-semibold rounded-lg prism-cta cursor-pointer"
                  >
                    Добавить
                  </button>
                </div>
              </form>
            )}

            <div className="grid sm:grid-cols-2 gap-3">
              {sortedRewards.map((reward) => {
                const canAfford = rewardState.balanceXp >= reward.costXp;
                const pct = Math.min(
                  100,
                  Math.round(
                    (rewardState.balanceXp / Math.max(1, reward.costXp)) * 100,
                  ),
                );
                const redeemedToday = rewardState.redeemedTodayIds.includes(
                  reward.id,
                );

                return (
                  <div
                    key={reward.id}
                    className={`rounded-xl border p-4 flex flex-col justify-between gap-3 transition-all ${
                      canAfford
                        ? 'border-emerald-400/80 dark:border-emerald-700/80 bg-emerald-50/40 dark:bg-emerald-950/20'
                        : 'border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#0E1522]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div
                          className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 ${
                            canAfford
                              ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'
                              : 'bg-slate-100 dark:bg-[#131B2B] text-slate-500 dark:text-[#94A3B8]'
                          }`}
                        >
                          <RewardIcon kind={reward.icon} />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-bold text-slate-950 dark:text-[#F3F4F6] leading-snug">
                            {reward.title}
                          </h4>
                          <p className="mt-0.5 text-xs text-slate-500 dark:text-[#94A3B8]">
                            {reward.subtitle} · {reward.breakMinutes} мин
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <span
                          className={`px-2 py-0.5 rounded-md font-mono text-xs font-bold tabular-nums ${
                            canAfford
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 dark:bg-[#131B2B] text-slate-700 dark:text-[#D1D5DB]'
                          }`}
                        >
                          {reward.costXp} XP
                        </span>
                        {reward.isCustom && (
                          <button
                            type="button"
                            onClick={() => onDeleteReward(reward.id)}
                            title="Удалить свою награду"
                            className="p-1 text-slate-400 hover:text-rose-500 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Progress or Claim Button */}
                    {canAfford ? (
                      <button
                        type="button"
                        onClick={() => onClaimReward(reward)}
                        className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-500 transition-colors cursor-pointer"
                      >
                        <Unlock className="h-3.5 w-3.5" />
                        <span>
                          {redeemedToday
                            ? 'Забрать допуск ещё раз'
                            : 'Разрешено! Забрать допуск и идти отдыхать'}
                        </span>
                      </button>
                    ) : (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-[#94A3B8]">
                          <span className="inline-flex items-center gap-1">
                            <Lock className="h-3 w-3" />
                            Ещё не открыто
                          </span>
                          <span className="font-mono tabular-nums">
                            {rewardState.balanceXp}/{reward.costXp} XP
                          </span>
                        </div>
                        <div className="h-1.5 w-full rounded-full bg-slate-100 dark:bg-[#131B2B] overflow-hidden">
                          <div
                            className="h-full bg-sky-500/80 transition-all duration-300"
                            style={{width: `${pct}%`}}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
